const accountId = 2003
let mail = "hridays2003@gmail.com"
var accountpwd="hello"
let accountstate
// let accountpwd = "bello"
console.table([accountId,mail,accountpwd,accountstate])