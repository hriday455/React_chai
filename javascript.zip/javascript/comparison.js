// console.log(2>1)
// console.log(2>=1)
console.log(null == 0)
console.log(null >= 0)
console.log(null <=0 );
console.log(null > 0);
console.log(0>0);

/*
reason is that equality check == and comparison > < >= <= work diffrently
comparison  converts null into a number , treating as a 0 
that's why (3) null >= 0 true and (1) null > 0 false  
*/




