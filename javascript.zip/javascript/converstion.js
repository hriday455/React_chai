let score = "33"
//console.log(typeof score)
let invalueNumber = Number(score)
//console.log(typeof invalueNumber)
//console.log(invalueNumber)
/*
"33" = 33
"Hello" = NaN
true = 1
false = 0
" " = false
"hello" = true
*/
let loggedin = ""
let inloggedin = Boolean (loggedin)
//console.log(typeof inloggedin)
//console.log(inloggedin)
let Somenumber = 33
let stringnumber = String(Somenumber)
//console.log(stringnumber)
//console.log(typeof stringnumber)
//**********************************************operations*********************************************************
let values = 3
let negvalues = -values
//console.log(negvalues)
//console.log(9**2)
let str1 = "Hridey"
let str2 = " Sharma"
let str3 = str1 + str2
//console.log(str3)
/*
console.log("1" + 2)
console.log("1" + "2")
console.log(1 + 2 + "3")
console.log("1" + "2" + 3)
*/
/*
console.log(+true)
console.log(+"")
console.log(+"hello")
*/
let gamecounter = 100
++gamecounter // prefix (search it on js.mdn)
console.log(gamecounter)
let gamecounter1 = 100
gamecounter1++ // postfix 
console.log(gamecounter1)

