"use strict"; // treat all js code as newer version
// primitive 
// 7 types : String , Number , Boolean , null , undefined , symbol , BigInt

// refrence type , Non Primitve
// Array , objects , functions
const bignumber = 756575657565756n
console.log(bignumber)