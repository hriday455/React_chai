// const jwt = require ("jsonwebtoken")
// const secret = "Hridey@123"
// function setUser(user){
//     if (!user || !user._id || !user.email) {
//         throw new Error("Invalid user object for JWT generation");
//     }
//      return jwt.sign({
//         _id:user._id,
//         email: user.email
//        },secret)
// }
// function getUser(token){
//     console.log("Received token:", token); 
//     if(!token){
//         console.error("No token provided.");
//          return null
//     }
//    return jwt.verify(token,secret)
// }
// module.exports={
//     setUser,
//     getUser
// }
const jwt = require ("jsonwebtoken");
const secret = "Hridey@123";

function setUser(user) {
  
    return jwt.sign({
        _id: user._id,
        email: user.email
    }, secret); // Added expiry time for security
}

function getUser(token) {
    console.log("Received token:", token);
    if (!token) {
        console.error("No token provided.");
        return null;
    }
    try {
        return jwt.verify(token, secret);
    } catch (error) {
        console.error("JWT verification failed:", error.message);
        return null;
    }
}

module.exports = {
    setUser,
    getUser
};
//jwt.sign() is a method from the jsonwebtoken library that creates a JWT token.
//jwt.sign(payload, secretKey, options);
//payload → The data to store inside the JWT (e.g., user ID and email).
//secretKey → A private key used to sign and secure the JWT.