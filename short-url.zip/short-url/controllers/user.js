const { v4: uuidv4 } = require("uuid");

const User = require('../models/user')
const { setUser }= require('../service/auth')
async function handleUserSignup(req,res){
    const{name,email,password}=req.body
    await User.create({
        name,
        email,
        password
    })
    return res.redirect("/")
}
async function handleUserLogin(req,res){
    const{email,password}=req.body
  const user =  await User.findOne({email,password})
  if(!user){
    return res.render("login",{
        error:"Invalid email or password",
    })
  }
//   const sessionId = uuidv4()
console.log("User found:", user); 

// Check if user is null/undefined
if (!user || !user._id || !user.email) {
    console.error("Invalid user object, cannot generate JWT:", user);
    return res.status(500).json({ error: "Failed to generate JWT" });
}
console.log("User found:", user); 
 const token = setUser({
    _id: user._id.toString(), // Ensure it's a string
    email: user.email
});
 
 console.log("Generated token:", token); 
  res.cookie("uid",token,{ httpOnly: true, secure: false, sameSite: "strict" })
    return res.redirect("/")
}
module.exports={
    handleUserSignup,
    handleUserLogin
}
/*
// const sessionId = uuidv4()
//     console.log("Generated UUID:", sessionId);
//     setUser(sessionId,user)
//     console.log("Stored in session map:", sessionIdToUserMap); 
//     res.cookie("uid",sessionId,{ httpOnly: true, secure: false, sameSite: "strict" })
//     console.log("Cookie Set:", sessionId);
// */
