const express = require("express")
const app = express()
const cookieParser = require("cookie-parser");
const path = require("path")// it is build in module
const {connectMongoDB} = require("./connection")
const urlroutes = require("./routes/url")
const URL = require("./models/url")
const userRoute = require("./routes/user")
const staticRoute = require("./routes/staticrouters")
const{restrictToLoggedInUserOnly,checkAuth}= require("./middleware/auth")
const port = 8001
connectMongoDB('mongodb://localhost:27017/short-url')
.then(()=>{
    console.log("Connected to MongoDB")
})
app.use(express.json())
app.use(express.urlencoded({extended:false}))
app.use(cookieParser());

app.use("/url",restrictToLoggedInUserOnly,urlroutes)
app.use("/",checkAuth,staticRoute)
app.use("/user",userRoute)
app.get('/url/:shortId',async(req,res)=>{
    const shortId = req.params.shortId
 const entry =  await URL.findOneAndUpdate({
        shortId
    },{
        $push:{
            vistHistory:{
                timestamp:Date.now()
            }
        }
    })
    res.redirect(entry.redirectURL)
})
app.set("view engine","ejs")
app.set("views",path.resolve("./views"))


app.listen(port,()=>{
    console.log(`Server is running on port ${port}`)
})
