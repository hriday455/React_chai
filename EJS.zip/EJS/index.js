const express = require("express")
const app = express()
const port = 8080
app.use(express.static("public"));

app.set("view engine","ejs")
app.get("/",(req,res)=>{
   // res.send("This is home")
   res.render("home.ejs")// render m ek sath puri file ko bhejte h 
})
app.get("/rollsdice",(req,res)=>{
    let dice =  Math.floor(Math.random() *6 ) + 1
    res.render("rolls.ejs",{dice})
})
app.get("/hello",(req,res)=>{
    res.send("Hello")
})
// instagram data.json we treated as a database
app.get("/ig/:username",(req,res)=>{
    let {username}=req.params
    const instadata = require("./data.json")
    let data = instadata[username]
    console.log(data);
    if(data){
        res.render("instagram.ejs",{data}) // (view template  , data property)
    }else{
        res.render("error.ejs")
    }
 
   

})
// app.get("/ig/:username",(req,res)=>{
//     let username = req.params
//     const followers = ["hriday_827","evilpremsharma","morningstarbrajeshpandey","diveshguha"]
//     res.render("instagram.ejs",{username,followers})
// })

app.listen(port,()=>{
    console.log(`Listening on port ${port}`)
})

