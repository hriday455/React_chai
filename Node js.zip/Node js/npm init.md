npm init
it is used to create our own package.json