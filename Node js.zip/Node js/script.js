//  touch script.js uses to make a new file in js 
// console.log(process.argv);
// let args = process.argv;
// for(let i=2;i<args.length;i++){
//     console.log('hello & welcome to' + args[i])
// }
// process.argv is used in Node.js to access command-line arguments passed to a script when it's executed. It allows you to make scripts dynamic by processing user input provided during execution.
/////////////////MODULE EXPORTS///////////////////////////////////////
// MODULE EXPORTS is a type of packages . It is a special object 
// use require to require the value . it is a built in function to include external modules that exits in seprate file
// const somevalue = require("./math");
// console.log(somevalue.sum(2,2));
// console.log(somevalue.mul(2,2));
const info = require("./fruits");
console.log(info)
