const sum = (a,b) => a+b;
const mul = (a,b) => a*b;
const g = 10;
const pi = 7.14;
module.exports= {
    sum: sum,
    mul: mul,
    g: g,
    pi: pi
}
