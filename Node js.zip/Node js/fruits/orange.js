module.exports ={
    fruit : "orange",
    color : "orange"
}