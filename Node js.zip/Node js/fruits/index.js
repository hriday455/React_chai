const apple = require("./apple");
const banana = require("./banana");
const orange = require("./orange");
let fruit = [apple ,banana ,orange];
 module.exports = fruit;
