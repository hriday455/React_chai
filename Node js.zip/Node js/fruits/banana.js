module.exports ={
    fruit : "banana",
    color : "yellow"
}