module.exports ={
    fruit : "apple",
    color : "red"
}