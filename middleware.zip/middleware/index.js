const express = require("express")
const app = express()
// app.use((req,res,next)=>{
//     console.log("Hi i am middleware")
//     res.send("Middleware finished")
//     next()
// })
// app.use("/api",(req,res,next)=>{
//     let {token}=req.query
//     if(token==="giveaccess"){
//         next()
//     }
//     res.send("Acess Denied!")
// })
// passing multiple middleware function
  const checktoken=(req,res,next)=>{
        let {token}=req.query
        if(token==="giveaccess"){
            next()
        }
        res.send("Acess Denied!")
    }
app.get("/api",checktoken,(req,res)=>{
    res.send("data")
})
app.get("/",(req,res)=>{
    res.send("Hi i am root")
})
app.get("/random",(req,res)=>{
    res.send("This is a rondom page")
})
app.listen(8080,()=>{
    console.log("Port is running")
})